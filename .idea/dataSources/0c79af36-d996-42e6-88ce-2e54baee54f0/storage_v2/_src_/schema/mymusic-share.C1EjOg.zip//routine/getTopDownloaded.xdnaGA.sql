CREATE
    DEFINER = `root`@`localhost` PROCEDURE `getTopDownloaded`(IN `numberOfMusic` INT)
SELECT
    `myokndefht_tracks`.`id`,
    `title`, `bpm`, `bitrate`, `releaseDate`, `path`, `hash`, `ispending`, `listenCount`, `id_musicKey`,
    GROUP_CONCAT(DISTINCT `myokndefht_artists`.`name` SEPARATOR ', ') AS `artistsName`,
    COUNT(DISTINCT `myokndefht_usersdownloadedtracks`.`id`) AS `downloadCount`,
    `myokndefht_musickey`.`musicKey`
FROM
    `myokndefht_tracks`
    INNER JOIN `myokndefht_artiststracks`
               ON `myokndefht_tracks`.`id` = `myokndefht_artiststracks`.`id_tracks`
    INNER JOIN `myokndefht_artists`
               ON `myokndefht_artiststracks`.`id_artists` = `myokndefht_artists`.`id`
    INNER
        JOIN `myokndefht_usersdownloadedtracks`
             ON `myokndefht_tracks`.`id` = `myokndefht_usersdownloadedtracks`.`id_tracks`
    INNER JOIN `myokndefht_musickey` ON `myokndefht_tracks`.`id_musicKey` = `myokndefht_musickey`.`id`
GROUP BY
    `myokndefht_usersdownloadedtracks`.`id_tracks`
ORDER BY
    `downloadCount` DESC
LIMIT numberOfMusic;

